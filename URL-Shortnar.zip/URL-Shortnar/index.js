
const express   = require('express');
const {connectMongo}= require('./connection')
const URL = require('./models/url')
const port = 8001;
const app = express();
const path  = require('path');



connectMongo('mongodb://localhost:27017/short-url')
.then(()=>{console.log('mongodb connect')})
.catch((err)=>{console.log("mongo connection err",err)});

const urlroute = require('./routes/url')
const staticRouter = require('./routes/staticRouter')


//set <-----ejs view engine---->
app.set("view engine","ejs");
app.set("views",path.resolve("./views"));



app.use(express.json())
//support for form data
app.use(express.urlencoded({extended:false}))

//this is dynamic route

app.use("/url",urlroute);
app.use("/",staticRouter);


app.get("/shortId/:id",async (req,res)=>{

    const shortId = req.params.id;
    const entry  =  await URL.findOneAndUpdate(

        {
            shortId
        },
        {
            $push:{
                visitHistory :{

                    timestamp:Date.now()

                },
            },
        }
    );
        res.redirect(entry.redirecturl);
   
});


app.listen(port , ()=>{console.log(`server started at port : ${port}`)})