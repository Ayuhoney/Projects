const express = require("express");
 
const {handlegeneratenewshorturl, handleGetAnalytics} = require('../controllers/url')

const router  = express.Router();

router.post("/",handlegeneratenewshorturl)

router.get("/click/:shortId",handleGetAnalytics)


module.exports = router;